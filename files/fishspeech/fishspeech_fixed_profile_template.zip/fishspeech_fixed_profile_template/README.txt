
# Fish-Speech Fixed Profile Template (Docker Compose)

This template demonstrates:
- One-time speaker profile enrollment (embedding / LoRA) and reuse
- Low-latency streaming synthesis API (FastAPI)
- TensorRT engine builder (placeholder)
- MySQL schema for profiles and request logs
- Redis for job queue/caching
- Korean text normalization & G2P worker stub

## Structure
- docker-compose.yml
- .env.sample
- services/
  - api/ (FastAPI app + stubs)
  - g2p/ (G2P worker placeholder)
  - trt-builder/ (TensorRT conversion placeholder)
- sql/schema_mysql.sql
- models/ (mount your base checkpoints here)
- profiles/ (generated embeddings/LoRA go here)
- engines/ (TensorRT engines)

## Usage
1) Copy `.env.sample` to `.env` and adjust paths.
2) Place base TTS and Vocoder checkpoints into `./models`.
3) `docker compose up --build`
4) POST /synthesize to http://localhost:8080

## Notes
- The ML parts are stubs for safety. Replace with your actual model code.
- Add enrollment endpoints/scripts to extract embeddings and train LoRA.
- For production, enable GPU for api service and bind to NVIDIA runtime.
