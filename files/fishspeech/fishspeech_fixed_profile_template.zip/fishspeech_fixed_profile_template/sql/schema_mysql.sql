
-- tts_speakers: fixed profile registry
CREATE TABLE IF NOT EXISTS tts_speakers (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  speaker_id VARCHAR(64) NOT NULL UNIQUE,
  profile_type ENUM('embedding','lora','embedding+lora') NOT NULL,
  embed_path VARCHAR(255),
  lora_path VARCHAR(255),
  locale VARCHAR(16) DEFAULT 'ko-KR',
  duration_sec FLOAT DEFAULT 0,
  base_model_ver VARCHAR(32) DEFAULT 'v1',
  abi_ver VARCHAR(16) DEFAULT '1',
  audio_sha256 CHAR(64),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- request logs (for monitoring SLOs)
CREATE TABLE IF NOT EXISTS tts_request_logs (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  request_id CHAR(36) NOT NULL,
  speaker_id VARCHAR(64),
  text_len INT,
  ttfb_ms INT,
  rtf FLOAT,
  status ENUM('OK','ERROR') DEFAULT 'OK',
  error_msg TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_speaker_id (speaker_id),
  INDEX idx_created_at (created_at)
);
