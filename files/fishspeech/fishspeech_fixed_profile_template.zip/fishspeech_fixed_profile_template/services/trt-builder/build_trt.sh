
#!/usr/bin/env bash
set -euo pipefail

: "${BASE_TTS_CKPT:=/models/tts_base.safetensors}"
: "${BASE_VOCODER_CKPT:=/models/vocoder_base.safetensors}"
: "${TRT_ENGINE_DIR:=/engines}"

mkdir -p "$TRT_ENGINE_DIR"

echo "[TRT] Converting base models to TensorRT engines (placeholders)..."
# NOTE: Replace the following with actual export to ONNX & TRT conversion commands.
# python export_to_onnx.py --ckpt "$BASE_TTS_CKPT" --out /tmp/acoustic.onnx
# trtexec --onnx=/tmp/acoustic.onnx --saveEngine="$TRT_ENGINE_DIR/acoustic_fp16.plan" --fp16

# python export_to_onnx.py --ckpt "$BASE_VOCODER_CKPT" --out /tmp/vocoder.onnx
# trtexec --onnx=/tmp/vocoder.onnx --saveEngine="$TRT_ENGINE_DIR/vocoder_fp16.plan" --fp16

echo "[TRT] Done. Engines saved in $TRT_ENGINE_DIR"
