
import time
import redis
import os
import json

r = redis.Redis(host=os.getenv("REDIS_HOST","redis"),
                port=int(os.getenv("REDIS_PORT","6379")), decode_responses=True)

QUEUE = "g2p:queue"
RESULT = "g2p:result"

def fake_g2p(text:str)->str:
    # Placeholder for actual g2p; return input for now
    return text

def main():
    print("[G2P] worker started")
    while True:
        item = r.blpop(QUEUE, timeout=1)
        if not item:
            continue
        _, payload = item
        job = json.loads(payload)
        out = fake_g2p(job["text"])
        r.hset(RESULT, job["id"], out)

if __name__ == "__main__":
    main()
