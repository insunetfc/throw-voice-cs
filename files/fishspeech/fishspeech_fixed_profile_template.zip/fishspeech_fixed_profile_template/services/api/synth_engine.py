
class AcousticModel:
    def __init__(self, ckpt:str):
        self.ckpt = ckpt
        # load model/trt engine here

    def set_speaker(self, emb):
        pass

    def load_lora(self, lora_path:str):
        pass

class Vocoder:
    def __init__(self, ckpt:str):
        self.ckpt = ckpt
        # load vocoder/trt engine here

    def stream(self, mel):
        # convert mel to pcm chunk
        pass
