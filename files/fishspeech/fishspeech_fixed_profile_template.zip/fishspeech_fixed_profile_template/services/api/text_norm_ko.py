
import re

# --- Basic Korean text normalization rules (expand as needed) ---

# Unit mappings
UNIT_MAP = {
    "kg": "킬로그램",
    "g": "그램",
    "km": "킬로미터",
    "m": "미터",
    "cm": "센티미터",
    "mm": "밀리미터",
    "°C": "도",
    "km/h": "킬로미터 퍼 아워",
    "m/s": "미터 퍼 세컨드",
    "%": "퍼센트"
}

def normalize_numbers(text: str) -> str:
    # 3.5 -> 삼 점 오 (simple, extend with sino/native readings by context)
    def repl_decimal(m):
        n = m.group(0)
        nums = {"0":"영","1":"일","2":"이","3":"삼","4":"사","5":"오","6":"육","7":"칠","8":"팔","9":"구"}
        if "." in n:
            a,b = n.split(".")
            a_read = "".join(nums.get(ch, ch) for ch in a)
            b_read = " ".join(nums.get(ch, ch) for ch in b)
            return f"{a_read} 점 {b_read}"
        return n
    text = re.sub(r"\d+\.\d+", repl_decimal, text)
    return text

def normalize_units(text: str) -> str:
    for k, v in UNIT_MAP.items():
        text = text.replace(k, " " + v + " ")
    return text

def normalize_english(text: str) -> str:
    # VERY rough mapping (extend as needed)
    text = re.sub(r"AI", "에이아이", text)
    text = re.sub(r"TTS", "티티에스", text)
    text = re.sub(r"GPU", "지피유", text)
    return text

def normalize_ko(text: str) -> str:
    text = normalize_numbers(text)
    text = normalize_units(text)
    text = normalize_english(text)
    # spacing cleanup
    text = re.sub(r"\s{2,}", " ", text).strip()
    return text
