
import os
import time
import uuid
import json
import numpy as np
from fastapi import FastAPI, Response
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import MySQLdb
import redis

from text_norm_ko import normalize_ko
from profile_loader import load_profile
from synth_engine import AcousticModel, Vocoder

APP_START = time.time()
app = FastAPI(title="FishSpeech Fixed-Profile API")

redis_cli = redis.Redis(host=os.getenv("REDIS_HOST","localhost"),
                        port=int(os.getenv("REDIS_PORT","6379")), decode_responses=False)

db = MySQLdb.connect(
    host=os.getenv("MYSQL_HOST","localhost"),
    user=os.getenv("MYSQL_USER","ttsuser"),
    passwd=os.getenv("MYSQL_PASSWORD","ttspw"),
    db=os.getenv("MYSQL_DATABASE","tts"),
    charset="utf8mb4"
)

acoustic = AcousticModel(os.getenv("BASE_TTS_CKPT","/models/tts_base.safetensors"))
vocoder = Vocoder(os.getenv("BASE_VOCODER_CKPT","/models/vocoder_base.safetensors"))

class SynthesizeReq(BaseModel):
    text: str
    speaker_id: str
    speed: float = 1.0
    pitch: float = 0.0
    stream: bool = True
    format: str = "wav"

@app.get("/healthz")
def healthz():
    return {"ok": True, "uptime_sec": time.time()-APP_START}

@app.post("/synthesize")
def synth(req: SynthesizeReq):
    started = time.time()
    request_id = str(uuid.uuid4())
    text = normalize_ko(req.text)
    tokens = text.split()  # placeholder tokenization

    # Load cached profile (embedding + optional LoRA)
    profile = load_profile(req.speaker_id)

    def audio_stream():
        nonlocal started
        # Simulate low-latency: 3 chunks
        for i in range(3):
            time.sleep(0.15 if i == 0 else 0.05)  # simulate compute
            pcm = (np.random.rand(24000*1)//1).astype(np.int16).tobytes()
            yield pcm

    # First chunk time (TTFB)
    ttfb_ms = None
    def wrapped_stream():
        nonlocal ttfb_ms, started
        first = True
        for chunk in audio_stream():
            if first:
                ttfb_ms = int((time.time()-started)*1000)
                first = False
            yield chunk

    resp = StreamingResponse(wrapped_stream(), media_type="audio/wav")

    # async log (simplified sync insert)
    try:
        with db.cursor() as cur:
            cur.execute(
                "INSERT INTO tts_request_logs (request_id, speaker_id, text_len, ttfb_ms, rtf, status) VALUES (%s,%s,%s,%s,%s,%s)",
                (request_id, req.speaker_id, len(text), ttfb_ms or 0, 0.1, "OK")
            )
        db.commit()
    except Exception as e:
        pass

    return resp
