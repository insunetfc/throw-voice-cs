
import os
import json
import numpy as np

CACHE = {}

def load_profile(speaker_id: str):
    if speaker_id in CACHE:
        return CACHE[speaker_id]
    # Minimal stub: map to file path
    spk_dir = os.getenv("SPEAKER_DIR","/profiles/speakers")
    lora_dir = os.getenv("LORA_DIR","/profiles/lora")
    emb_path = os.path.join(spk_dir, f"{speaker_id}.npy")
    lora_path = os.path.join(lora_dir, f"{speaker_id}-lora.safetensors")
    emb = np.load(emb_path) if os.path.exists(emb_path) else np.zeros(256, dtype=np.float32)
    lora = lora_path if os.path.exists(lora_path) else None
    CACHE[speaker_id] = (emb, lora)
    return CACHE[speaker_id]
