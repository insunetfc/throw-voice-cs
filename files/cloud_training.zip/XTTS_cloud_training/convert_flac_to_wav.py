import os
import soundfile as sf

audio_root = "VALL-E/KsponSpeech_dataset/TTS/wavs"  # Adjust this to your folder

converted = 0
failed = 0

for root, dirs, files in os.walk(audio_root):
    for file in files:
        if file.endswith(".flac"):
            flac_path = os.path.join(root, file)
            wav_path = os.path.join(root, file[:-5] + ".wav")
            try:
                data, samplerate = sf.read(flac_path)
                sf.write(wav_path, data, samplerate)
                converted += 1
            except Exception as e:
                print(f"❗ Failed to convert {flac_path}: {e}")
                failed += 1

print(f"✅ Done! Converted {converted} files. Failed: {failed}.")