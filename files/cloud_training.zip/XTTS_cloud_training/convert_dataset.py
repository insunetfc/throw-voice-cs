import os

# Where your dataset is located
DATASET_ROOT = "/home/work/VALL-E/KsponSpeech_dataset/TTS/"
OUTPUT_FILE = os.path.join(DATASET_ROOT, "metadata.txt")

# TRN files (adjust to your actual paths)
trn_files = {
    "train": [
        "/home/work/VALL-E/KsponSpeech_dataset/TTS/dev.trn",
        "/home/work/VALL-E/KsponSpeech_dataset/TTS/train.trn",
    ],
    "eval": [
        "/home/work/VALL-E/KsponSpeech_dataset/TTS/eval_clean.trn",
        "/home/work/VALL-E/KsponSpeech_dataset/TTS/eval_other.trn",
    ]
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as fout:
    # Process training .trn
    for trn_path in trn_files["train"]:
        with open(trn_path, "r", encoding="utf-8") as fin:
            for line in fin:
                parts = line.strip().split(" :: ")
                if len(parts) != 2:
                    continue
                path, text = parts
                rel_path = os.path.join("train", path.replace(".pcm", ""))
                fout.write(f"{rel_path}|{text}|{text}\n")

    # Process eval .trn
    for trn_path in trn_files["eval"]:
        with open(trn_path, "r", encoding="utf-8") as fin:
            for line in fin:
                parts = line.strip().split(" :: ")
                if len(parts) != 2:
                    continue
                path, text = parts
                # change path to eval/{eval_clean|eval_other}/xxx
                rel_path = os.path.join("eval", os.path.relpath(path, "KsponSpeech_eval").replace(".pcm", ""))
                fout.write(f"{rel_path}|{text}|{text}\n")