import os
import re

input_meta = "/home/work/VALL-E/KsponSpeech_dataset/TTS/metadata.txt"  # Your original metadata file
output_meta = "/home/work/VALL-E/KsponSpeech_dataset/TTS/metadata_cleaned_verified.txt"  # Output file
audio_root = "/home/work/VALL-E/KsponSpeech_dataset/TTS/wavs"  # Adjust this to your dataset root
max_length = 95

kept = 0
missing = 0

with open(input_meta, "r", encoding="utf-8") as fin, \
     open(output_meta, "w", encoding="utf-8") as fout:
    for line in fin:
        parts = line.strip().split("|")
        if len(parts) != 3:
            continue
        fname, text, _ = parts
        # Clean text markers
        cleaned_text = re.sub(r"^(o/|아/|어/)\s*", "", text)
        cleaned_text = cleaned_text.replace("/", " ").replace("+", "").strip()
        # Strip extension if present
        fname_base = fname[:-5] if fname.endswith(".flac") else fname
        # Check if .wav file exists
        if os.path.exists(os.path.join(audio_root, fname_base + ".wav")) and len(cleaned_text) <= max_length:
            fout.write(f"{fname_base}|{cleaned_text}|{cleaned_text}\n")
            kept += 1
        else:
            missing += 1

print(f"✅ Done! Kept {kept} valid entries, removed {missing} missing/too long entries.")
